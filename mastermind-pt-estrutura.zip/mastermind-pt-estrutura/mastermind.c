#include <stdio.h>
#include <stdlib.h>
#include "mastermind.h"
#include "codigo.h"
#include "jogador.h"
#include "cor.h"

/**
 * @brief
 *
 */



/**
 * @brief 
 *
 * @param m 
 * @param semente 
 * @param numPins 
 * @param p 
 */
void iniciarMastermind(Mastermind* m, int semente, int numPins, Jogador* p) {
    
}

/**
 * @brief 
 *
 * @param m 
 */
void iniciarRonda(Mastermind* m) {
    
}


/**
 * @brief 
 *
 * @param m 
 * @param tentativa 
 */
void efetuaJogada(Mastermind* m, Codigo* tentativa) {
    
}

/**
 * @brief 
 *
 * @param 
 * @return 
 */
bool estaTerminadaARonda(Mastermind* m) {
    return true;
}

/**
 * @brief 
 *
 * @param m 
 * @param buffer 
 * @param size 
 */
void mastermindParaString(Mastermind* m, char buffer[], int size) {
    
}


/**
 * @brief 
 *
 * @param m 
 * @return 
 */
int obterNumeroTentativas(Mastermind* m) {
    return -1;
}

/**
 * @brief 
 *
 * @param m 
 * @return 
 */
bool oSegredoFoiRevelado(Mastermind* m){
    return false;
}

/**
 * @brief 
 *
 * @param m 
 * @return 
 */
int obterNumeroDePins(Mastermind* m) {
    return -1;
}

/**
 * @brief 
 *
 * @param m 
 * @return 
 */
Jogador* obterJogador(Mastermind* m) {
    return NULL;
}

/**
 * @brief 
 *
 * @param m 
 * @return 
 */
int obterPontuacao(Mastermind* m) {
    
    return -1;
}
