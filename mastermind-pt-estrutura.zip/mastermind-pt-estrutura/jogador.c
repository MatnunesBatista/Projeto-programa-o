#include <stdio.h>
#include "jogador.h"


/**
 * @brief 
 * 
 * @param nome 
 * @return 
 */

 void criaJogador(Jogador* p, const char* nome) {
    
}

/**
 * @brief 
 * 
 * @param p 
 * @return 
 */
const char* obtemNomeJogador(const Jogador* p) { 
    return ' ';
}

/**
 * @brief 
 * 
 * @param 
 * @return 
 */
int obtemVitoriasJogador(const Jogador* p) { 
    return -1; 
}

/**
 * @brief 
 * 
 * @param 
 * @return 
 */
int obtemDerrotasJogador(const Jogador* p) {
    return -1; 
}

/**
 * @brief 
 * 
 * @param 
 */
void adicionaVitoria(Jogador* p) { 
    
}

/**
 * @brief 
 * 
 * @param 
 */
void adicionaDerrota(Jogador* p) {
    
}

/**
 * @brief 
 * 
 * @param  p
 * @param buffer
 * @param buffer_size
 */
void jogadorParaString(const Jogador* p, char* buffer, int buffer_size) {
    
}
