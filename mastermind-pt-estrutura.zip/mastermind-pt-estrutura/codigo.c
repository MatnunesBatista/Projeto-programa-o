#include <stdlib.h>
#include <stdbool.h>
#include <time.h>
#include "codigo.h"
#include "cor.h"


/**
 * @brief 
 * 
 * @param c 
 * @param colors 
 * @param size 
 * @param seed 
 */
void gerarCodigo(Codigo *c, Cor cores[], int size) {

}

/**
 * @brief 
 * 
 * @param c 
 * @return 
 */
Codigo copia(Codigo *c) {
    
    return;
}

/**
 * @brief 
 * 
 * @param 
 * @param b 
 * @return 
 */
bool iguais(Codigo *a, Codigo *b) {
    return false;
}

/**
 * @brief 
 * 
 * @param 
 * @param 
 * @param 
 * @param 
 */
void quantasCorretas(Codigo *secrego, Codigo *tentativa, int *a, int *b) {
 
}


/**
 * @brief 
 * 
 * @param c 
 * @param repString .
 */
void codigoParaString(Codigo* c, char repString[TAMANHO_CODIGO + 1]){
    
}
