#include <stdio.h>
#include <string.h>
#include "../mastermind.h"
#include "../jogador.h"
#include "../cor.h"

int tests_passed = 0;
int tests_failed = 0;

void run_test(int condition, const char *test_name, const char *expected, const char *got)
{
    if (condition)
    {
        tests_passed++;
        printf("✔ %s passou\n", test_name);
    }
    else
    {
        tests_failed++;
        printf("✘ %s falhou\n", test_name);
        if (expected && got)
        {
            printf("  Esperado: %s\n", expected);
            printf("  Obtido:   %s\n", got);
        }
    }
}

// Cria um código a partir de cores usando apenas API pública
Codigo createCode(Cor colors[], int len)
{
    Codigo c;
    gerarCodigo(&c, colors, len);
    return c;
}

int main()
{
    printf("=== Testes unitarios para Mastermind (API publica) ===\n");

    Jogador p;
    criaJogador(&p, "Alice");

    Mastermind m;
    iniciarMastermind(&m, 123, 4, &p);

    // Buffer para armazenar a string do Mastermind
    char buffer[1024];

    // Teste 1: ronda inicializa corretamente
    run_test(obterNumeroTentativas(&m) == 0, "Numero de tentativas começa em 0", NULL, NULL);
    run_test(!estaTerminadaARonda(&m), "Ronda nao terminada no inicio", NULL, NULL);
    run_test(obterNumeroDePins(&m) == 4, "Tamanho do codigo correto", NULL, NULL);

    // Teste 2: jogar tentativa errada incrementa trialNumber
    Cor trial_arr1[] = {ORANGE, GREEN, BLUE, YELLOW};
    Codigo trial1 = createCode(trial_arr1, 4);

    efetuaJogada(&m, &trial1);
    run_test(obterNumeroTentativas(&m) == 1, "TrialNumber incrementa apos tentativa", NULL, NULL);
    run_test(!estaTerminadaARonda(&m), "Ronda nao termina com tentativa errada", NULL, NULL);

    // Teste 3: testar saída de mastermindParaString
    // Vamos criar um código previsível usando trial1 para que a saída seja conhecida
    iniciarRonda(&m); // reinicia a ronda
    efetuaJogada(&m, &trial1); // primeira tentativa

    mastermindParaString(&m, buffer, sizeof(buffer));

    // String esperada (exemplo, ajusta de acordo com como mastermindParaString formata)
    // '?' para o código secreto ainda não descoberto, e trial1 mostrado na primeira linha
    const char *expected_output =
        "\n===== ESTADO DO JOGO =====\n"
        "Tentativas: 1\n"
        "Codigo secreto: ? ? ? ? \n"
        "OGBY -> 1 1\n"
        "\n"
        "===== PONTUACAO =====\n"
        "Jogador: Alice\n"
        "Vitorias: 0\n"
        "Derrotas: 0\n"
        "=================\n"
        "===========================\n";

    run_test(strcmp(buffer, expected_output) == 0,
             "mastermindParaString produz saida correta apos 1 tentativa",
             expected_output,
             buffer);

    // Teste 4: jogar MAX_TRIALS-1 tentativas erradas termina ronda na última
    iniciarRonda(&m);
    for (int i = 0; i < NUM_MAX_TENTATIVAS - 1; i++)
        efetuaJogada(&m, &trial1);
    run_test(!estaTerminadaARonda(&m), "Ronda ainda nao termina antes da ultima tentativa", NULL, NULL);
    efetuaJogada(&m, &trial1); // última tentativa
    run_test(estaTerminadaARonda(&m), "Ronda termina apos MAX_TRIALS tentativas", NULL, NULL);
    run_test(obtemDerrotasJogador(&p) == 1, "Derrota adicionada ao jogador", NULL, NULL);

    // Teste 5: tentar jogar após ronda terminada não altera trialNumber
    int tn_before = obterNumeroTentativas(&m);
    efetuaJogada(&m, &trial1);
    run_test(obterNumeroTentativas(&m) == tn_before, "TrialNumber nao incrementa apos ronda terminada", NULL, NULL);

    // Teste 6: startNewRound reinicia trialNumber e ended
    iniciarRonda(&m);
    run_test(obterNumeroTentativas(&m) == 0, "Nova ronda reinicia trialNumber", NULL, NULL);
    run_test(!estaTerminadaARonda(&m), "Nova ronda reinicia ended", NULL, NULL);

    // =========================
    // Testes de oSegredoFoiRevelado()
    // =========================
    printf("\n--- Testes de oSegredoFoiRevelado ---\n");

    // Garante que começa como false
    iniciarRonda(&m);
    run_test(!oSegredoFoiRevelado(&m), "Segredo nao revelado no inicio", "false", oSegredoFoiRevelado(&m) ? "true" : "false");

    // Simula jogadas erradas ate acabar a ronda (sem adivinhar o codigo)
    for (int i = 0; i < NUM_MAX_TENTATIVAS; i++)
        efetuaJogada(&m, &trial1);
    run_test(estaTerminadaARonda(&m), "Ronda termina apos varias jogadas", "true", estaTerminadaARonda(&m) ? "true" : "false");
    run_test(!oSegredoFoiRevelado(&m), "Segredo nao revelado apos derrota", "false", oSegredoFoiRevelado(&m) ? "true" : "false");

    // Agora simula vitória — o jogador adivinha o código
    iniciarRonda(&m);
    
    Cor seq2[] = {YELLOW, GREEN, YELLOW, PURPLE};
    char buf[TAMANHO_CODIGO+1];
    Codigo trialSecret;
    gerarCodigo(&trialSecret, seq2, 4);

    efetuaJogada(&m, &trialSecret);
    run_test(oSegredoFoiRevelado(&m), "Segredo revelado apos vitoria", "true", oSegredoFoiRevelado(&m) ? "true" : "false");

    // Inicia nova ronda e verifica que o estado é reiniciado
    iniciarRonda(&m);
    run_test(!oSegredoFoiRevelado(&m), "Segredo volta a ocultar apos nova ronda", "false", oSegredoFoiRevelado(&m) ? "true" : "false");

    // Teste 7: mastermindParaString após nova ronda
    mastermindParaString(&m, buffer, sizeof(buffer));
    printf("\n--- Saída de mastermindParaString após startNewRound ---\n%s\n", buffer);

    printf("\n=== RESULTADOS ===\n");
    printf("Passaram: %d\n", tests_passed);
    printf("Falharam: %d\n", tests_failed);

    return (tests_failed == 0) ? 0 : 1;
}
