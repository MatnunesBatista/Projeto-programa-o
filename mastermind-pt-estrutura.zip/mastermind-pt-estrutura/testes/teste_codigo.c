#include <stdio.h>
#include <string.h>
#include "../codigo.h"

int tests_passed = 0;
int tests_failed = 0;

// nova função run_test com expected/obtido
void run_test(int condition, const char* test_name, const char* expected, const char* obtained) {
    if (condition) {
        tests_passed++;
        printf("✔ %s passou\n", test_name);
    } else {
        tests_failed++;
        printf("✘ %s falhou | Esperado: %s | Obtido: %s\n", test_name, expected, obtained);
    }
}

// Função auxiliar para criar uma string "a,b" para a e b
void makeABString(int a, int b, char* buffer) {
    sprintf(buffer, "%d,%d", a, b);
}

int main() {
    printf("=== Testes unitários para codigo.c (API pública) ===\n");

    char buf[TAMANHO_CODIGO+1];
    int a, b;

    // =========================
    // Testes de copia() e iguais() usando apenas API pública
    // =========================
    Cor seq1[] = {RED, GREEN, BLUE, YELLOW};
    Codigo c1;
    gerarCodigo(&c1, seq1, 4);
    Codigo c2 = copia(&c1);
    run_test(iguais(&c1, &c2), "copia preserva os valores", "true", iguais(&c1, &c2) ? "true" : "false");

    Cor seq2[] = {GREEN, BLUE, BLUE, BLUE};
    Codigo c3;
    gerarCodigo(&c3, seq2, 4);
    Codigo copy1 = copia(&c3);
    run_test(iguais(&c3, &copy1), "copia funciona para 4 elementos", "true", iguais(&c3, &copy1) ? "true" : "false");

    // Alterar cópia e testar que original não muda
    Cor seq3[] = {GREEN, BLUE, GREEN, BLUE};
    gerarCodigo(&c3, seq3, 4);
    Codigo copy2 = copia(&c3);
    // gerar um código diferente para comparar
    Cor seq4[] = {RED, RED, RED, RED};
    gerarCodigo(&c3, seq4, 4);
    run_test(!iguais(&c3, &copy2), "copia devolve cópia independente", "false", !iguais(&c3, &copy2) ? "false" : "true");

    // =========================
    // Testes de quantasCorretas via API
    // =========================
    Codigo secret, trial;

    Cor s1_arr[] = {GREEN, BLUE, BLUE, BLUE};
    Cor t1_arr[] = {GREEN, BLUE, BLUE, BLUE};
    gerarCodigo(&secret, s1_arr, 4);
    gerarCodigo(&trial, t1_arr, 4);
    quantasCorretas(&secret, &trial, &a, &b);
    makeABString(a,b,buf);
    run_test(a==4 && b==0, "quantasCorretas teste1 (tudo certo)", "4,0", buf);

    Cor s2_arr[] = {BLUE, BLUE, BLUE, BLUE};
    Cor t2_arr[] = {GREEN, GREEN, GREEN, GREEN};
    gerarCodigo(&secret, s2_arr, 4);
    gerarCodigo(&trial, t2_arr, 4);
    quantasCorretas(&secret, &trial, &a, &b);
    makeABString(a,b,buf);
    run_test(a==0 && b==0, "quantasCorretas teste2 (nenhuma cor)", "0,0", buf);

    // =========================
    // Testes de toStringCode via API
    // =========================
    Cor tCode_arr[] = {RED, GREEN, BLUE, YELLOW};
    gerarCodigo(&trial, tCode_arr, 4);
    codigoParaString(&trial, buf);
    run_test(strcmp(buf, "RGBY")==0, "codigoParaString converte corretamente", "RGBY", buf);

    Cor tCode2_arr[] = {PURPLE, ORANGE, GREEN, RED, BLUE};
    gerarCodigo(&trial, tCode2_arr, 5);
    codigoParaString(&trial, buf);
    run_test(strcmp(buf, "POGRB")==0, "codigoParaString com 5 cores", "POGRB", buf);

    Cor tCode3_arr[] = {BLUE, BLUE, GREEN};
    gerarCodigo(&trial, tCode3_arr, 3);
    codigoParaString(&trial, buf);
    run_test(strcmp(buf, "BBG")==0, "codigoParaString com 3 cores", "BBG", buf);

    // =========================
    // Resumo final
    // =========================
    printf("\n=== RESULTADOS ===\n");
    printf("Total de testes: %d\n", tests_passed + tests_failed);
    printf("Passaram: %d\n", tests_passed);
    printf("Falharam: %d\n", tests_failed);

    return (tests_failed == 0) ? 0 : 1;
}
