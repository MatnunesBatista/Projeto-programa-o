#include <stdio.h>
#include <string.h>
#include "../jogador.h"

int tests_passed = 0;
int tests_failed = 0;

void run_test(int condition, const char* test_name, const char* expected, const char* obtained) {
    if (condition) {
        tests_passed++;
        printf("✔ %s passou\n", test_name);
    } else {
        tests_failed++;
        printf("✘ %s falhou\n", test_name);
        if (expected && obtained)
            printf("   Esperado: %s\n   Obtido:   %s\n", expected, obtained);
    }
}

int main() {
    printf("=== Testes unitários para player.c ===\n");

    // =========================
    // Teste 1: criação do jogador
    // =========================
    Jogador p;
    criaJogador(&p, "TestUser"); 

    run_test(strcmp(obtemNomeJogador(&p), "TestUser") == 0, "obtemNomeJogador retorna o nome correto", "TestUser", obtemNomeJogador(&p));
    run_test(obtemVitoriasJogador(&p) == 0, "obtemVitoriasJogador inicia a 0", "0", "0"); // Wins são inteiros, simplificação
    run_test(obtemDerrotasJogador(&p) == 0, "obtemDerrotasJogador inicia a 0", "0", "0");

    // =========================
    // Teste 2: adicionar vitórias
    // =========================
    adicionaVitoria(&p);
    run_test(obtemVitoriasJogador(&p) == 1, "obtemVitoriasJogador incrementa vitorias", "1", "1");
    adicionaVitoria(&p);
    run_test(obtemVitoriasJogador(&p) == 2, "obtemVitoriasJogador pode ser chamado varias vezes", "2", "2");

    // =========================
    // Teste 3: adicionar derrotas
    // =========================
    adicionaDerrota(&p);
    run_test(obtemDerrotasJogador(&p) == 1, "obtemDerrotasJogador incrementa derrotas", "1", "1");
    adicionaDerrota(&p);
    adicionaDerrota(&p);
    run_test(obtemDerrotasJogador(&p) == 3, "obtemDerrotasJogador acumula corretamente", "3", "3");

    // =========================
    // Teste 4: verificar saída com jogadorParaString
    // =========================
    char scoreStr[256];
    jogadorParaString(&p, scoreStr, sizeof(scoreStr));
    const char *expectedScore = 
        "\n===== PONTUACAO =====\n"
        "Jogador: TestUser\n"
        "Vitorias: 2\n"
        "Derrotas: 3\n"
        "=================\n";
    run_test(strcmp(scoreStr, expectedScore) == 0, "jogadorParaString produz saida correta", expectedScore, scoreStr);

    // =========================
    // Teste 5: limites de nome (truncamento)
    // =========================
    Jogador longName;
    const char *veryLong = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";
    criaJogador(&longName, veryLong);
    run_test(strlen(obtemNomeJogador(&longName)) <= 49, "nome truncado corretamente (máx. 49 chars)", "<=49", obtemNomeJogador(&longName));

    // =========================
    // Resumo final
    // =========================
    printf("\n=== RESULTADOS ===\n");
    printf("Passaram: %d\n", tests_passed);
    printf("Falharam: %d\n", tests_failed);

    return (tests_failed == 0) ? 0 : 1;
}
