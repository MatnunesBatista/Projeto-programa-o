#include <stdio.h>
#include <string.h>
#include "../cor.h"

int tests_passed = 0;
int tests_failed = 0;

// Teste para inteiros
void run_test_int(int got, int expected, const char* test_name) {
    if (got == expected) {
        tests_passed++;
        printf("✔ %s passou\n", test_name);
    } else {
        tests_failed++;
        printf("✘ %s falhou: esperado=%d, obtido=%d\n", test_name, expected, got);
    }
}

// Teste para strings
void run_test_str(const char* got, const char* expected, const char* test_name) {
    if (strcmp(got, expected) == 0) {
        tests_passed++;
        printf("✔ %s passou\n", test_name);
    } else {
        tests_failed++;
        printf("✘ %s falhou: esperado='%s', obtido='%s'\n", test_name, expected, got);
    }
}

int main() {
    printf("=== Testes unitários para color.c ===\n");

    // Teste 1: corParaString (valores válidos)
    run_test_str(corParaString(RED), "R", "corParaString RED");
    run_test_str(corParaString(GREEN), "G", "corParaString GREEN");
    run_test_str(corParaString(BLUE), "B", "corParaString BLUE");
    run_test_str(corParaString(YELLOW), "Y", "corParaString YELLOW");
    run_test_str(corParaString(ORANGE), "O", "corParaString ORANGE");
    run_test_str(corParaString(PURPLE), "P", "corParaString PURPLE");

    // Teste 2: corParaString com valor inválido
    run_test_str(corParaString(-1), "UNKNOWN", "corParaString(-1) UNKNOWN");
    run_test_str(corParaString(100), "UNKNOWN", "corParaString(100) UNKNOWN");

    // Teste 3: nomeParaCor (valores válidos)
    run_test_int(nomeParaCor("R"), RED, "nomeParaCor RED");
    run_test_int(nomeParaCor("G"), GREEN, "nomeParaCor GREEN");
    run_test_int(nomeParaCor("B"), BLUE, "nomeParaCor BLUE");
    run_test_int(nomeParaCor("Y"), YELLOW, "nomeParaCor YELLOW");
    run_test_int(nomeParaCor("O"), ORANGE, "nomeParaCor ORANGE");
    run_test_int(nomeParaCor("P"), PURPLE, "nomeParaCor PURPLE");

    // Teste 4: nomeParaCor com string inválida
    run_test_int(nomeParaCor("pink"), -1, "nomeParaCor pink");
    run_test_int(nomeParaCor(""), -1, "nomeParaCor vazio");
    run_test_int(nomeParaCor("123"), -1, "nomeParaCor 123");

    // Resumo final
    printf("\n=== RESULTADOS ===\n");
    printf("Passaram: %d\n", tests_passed);
    printf("Falharam: %d\n", tests_failed);

    return (tests_failed == 0) ? 0 : 1;
}
