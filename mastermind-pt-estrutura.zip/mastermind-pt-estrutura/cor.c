#include "cor.h"

/**
 * @brief 
 */
const char* nomeCores[] = {
    "R", "G", "B", "Y", "O", "P"
};

/**
 * @brief 
 *
 * @param c 
 * @return 
 *         
 */
const char* corParaString(Cor c) {
    
    return "UNKNOWN";
}

/**
 * @brief 
 *
 * @param nome 
 * @return 
 */
int nomeParaCor(const char* nome) {
    return -1;
}
